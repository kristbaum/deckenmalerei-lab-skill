# Deckenmalerei-Lab Skill

Skill für die Nutzung des [Deckenmalerei-Lab](https://badwcbd-lab.srv.mwn.de/).

## Installation

### Claude.ai

Den Skill in Claude.ai einrichten:

1. [claude.ai/customize/skills](https://claude.ai/customize/skills) öffnen
2. Auf „+" → „+ Skill" → „Skill hochladen" klicken
3. Die Zip-Datei hochladen

### ChatGPT

Den Skill als **Custom GPT** einrichten (erfordert Plus oder Pro):

1. [chatgpt.com/gpts](https://chatgpt.com/gpts) öffnen
2. Auf „+ Create" klicken
3. Custom GPT mit den Skill-Dateien einrichten und speichern

### Localhost

docker run -d -p 3000:8080 -e WEBUI_AUTH=False -v ollama:/root/.ollama -v open-webui:/app/backend/data --name open-webui ghcr.io/open-webui/open-webui:ollama

# Deckenmalerei-Lab — System Prompt für kleine lokale Modelle

> Zum Einfügen in das System-Prompt-Feld von Open WebUI (Workspace → Modelle → dein Modell → System Prompt) oder in den `SYSTEM`-Block eines Ollama Modelfiles. Gedacht für 3B–8B-Klasse-Modelle (z. B. Gemma 4 E4B, Ministral 3B, Qwen3.5 7B) mit Zugriff auf den Deckenmalerei-Lab MCP-Server (`badwcbd-lab.srv.mwn.de/mcp`).
